create definer = root@`%` view account_stat as
select `stock`.`account_stocks`.`stock_code`                                                                      AS `stock_code`,
       `stock`.`accounts`.`account`                                                                               AS `account`,
       `stock`.`account_stocks`.`cost`                                                                            AS `cost`,
       `stock`.`account_stocks`.`number`                                                                          AS `number`,
       `stock`.`stocks`.`current_price`                                                                           AS `current_price`,
       `stock`.`stocks`.`stock_name`                                                                              AS `stock_name`,
       `stock`.`accounts`.`account_name`                                                                          AS `account_name`,
       `stock`.`accounts`.`accu_earning`                                                                          AS `accu_earning`,
       (`stock`.`account_stocks`.`number` *
        (`stock`.`stocks`.`current_price` - `stock`.`account_stocks`.`cost`))                                     AS `stock_earning`
from ((`stock`.`account_stocks` left join `stock`.`stocks` on ((`stock`.`account_stocks`.`stock_code` = `stock`.`stocks`.`stock_code`)))
         left join `stock`.`accounts` on ((`stock`.`account_stocks`.`account` = `stock`.`accounts`.`account`)));

